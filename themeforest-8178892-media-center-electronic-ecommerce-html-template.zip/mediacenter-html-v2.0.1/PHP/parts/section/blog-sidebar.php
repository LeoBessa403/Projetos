<aside class="sidebar blog-sidebar">
	
	<?php require MC_ROOT.'/parts/widgets/sidebar/sidebar-search.php';?>

	<?php require MC_ROOT.'/parts/widgets/sidebar/about-blog.php';?>

	<?php require MC_ROOT.'/parts/widgets/sidebar/blog-categories.php';?>

	<?php require MC_ROOT.'/parts/widgets/sidebar/sidebar-banner.php';?>

	<?php require MC_ROOT.'/parts/widgets/sidebar/recent-posts.php';?>

	<?php require MC_ROOT.'/parts/widgets/sidebar/tag-cloud.php';?>

</aside><!-- /.sidebar .blog-sidebar -->