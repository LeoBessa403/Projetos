<section id="reply-block" class="leave-reply">
	<h3>Leave a Reply</h3>
	<p>Your email address cannot be published. Required fields are marked <abbr class="required">*</abbr> </p>

	<form role="form" class="reply-form cf-style-1">
		<div class="row field-row">
			<div class="col-xs-12 col-sm-6">
				<label>full name*</label>
				<input class="le-input">
			</div>
			<div class="col-xs-12 col-sm-6">
				<label>last name*</label>
				<input class="le-input">
			</div>
		</div>

		<div class="row field-row">
			<div class="col-xs-12">
				<label>company name</label>
				<textarea rows="10" id="inputComment" class="form-control le-input"></textarea>
			</div>
		</div>


		<button class="le-button big post-comment-button" type="submit">Post comment</button>
	</form>

</section>	