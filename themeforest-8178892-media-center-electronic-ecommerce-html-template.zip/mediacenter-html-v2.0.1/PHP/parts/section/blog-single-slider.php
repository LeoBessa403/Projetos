<!-- ========================================== SECTION – HERO ========================================= -->
			
<div id="hero">
	<div id="owl-main" class="owl-carousel owl-carousel-blog owl-inner-nav owl-ui-sm">
		
		<div class="item">
			<img src="assets/images/blog-post/slider-1.jpg" alt="">
		</div><!-- /.item -->

		<div class="item">
			<img src="assets/images/blog-post/slider-2.jpg" alt="">
		</div><!-- /.item -->

		<div class="item">
			<img src="assets/images/blog-post/slider-1.jpg" alt="">
		</div><!-- /.item -->

	</div><!-- /.owl-carousel -->
</div>
			
<!-- ========================================= SECTION – HERO : END ========================================= -->