<section id="comments" class="inner-bottom-xs">
    <h3>2 Comments</h3>

    <div class="comment-item">
        <div class="row no-margin">
            <div class="col-lg-1 col-xs-12 col-sm-2 no-margin">
                <div class="avatar">
                    <img src="assets/images/default-avatar.jpg" alt="avatar">
                </div>
            </div>
            <div class="col-xs-12 col-lg-11 col-sm-10 no-margin-right">
                <div class="comment-body">
                    <div class="meta-info">
                        <header class="row no-margin">
                            <div class="pull-left">
                                <h4 class="author"><a href="#">Angela</a></h4>
                                <span class="date">- 21 hours ago</span>
                                <span class="likes"><a href="#"><span class="likes-count">22</span><i class="icon fa fa-thumbs-up"></i></a></span>
                                <span class="dislikes"><a href="#"><i class="icon fa fa-thumbs-down"></i></a></span>
                            </div>
                            <div class="pull-right">
                                <a class="comment-reply" href="#">Reply</a>
                            </div>
                        </header>
                    </div>
                    <p class="comment-content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                </div>
            </div>
        </div>
    </div>

    <div class="comment-item">
        <div class="row no-margin">
            <div class="col-lg-1 col-xs-12 col-sm-2 no-margin">
                <div class="avatar">
                    <img src="assets/images/default-avatar.jpg" alt="avatar">
                </div>
            </div>
            <div class="col-xs-12 col-lg-11 col-sm-10 no-margin-right">
                <div class="comment-body">
                    <div class="meta-info">
                        <header class="row no-margin">
                            <div class="pull-left">
                                <h4 class="author"><a href="#">Angela</a></h4>
                                <span class="date">- 21 hours ago</span>
                                <span class="likes"><a href="#"><span class="likes-count">22</span><i class="icon fa fa-thumbs-up"></i></a></span>
                                <span class="dislikes"><a href="#"><i class="icon fa fa-thumbs-down"></i></a></span>
                            </div>
                            <div class="pull-right">
                                <a class="comment-reply" href="#">Reply</a>
                            </div>
                        </header>
                    </div>
                    <p class="comment-content">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. </p>
                </div>
            </div>
        </div>
    </div>
</section>