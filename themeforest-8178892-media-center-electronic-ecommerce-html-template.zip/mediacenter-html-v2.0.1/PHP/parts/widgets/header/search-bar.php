<div class="contact-row">
    <div class="phone inline">
        <i class="fa fa-phone"></i> (+800) 123 456 7890
    </div>
    <div class="contact inline">
        <i class="fa fa-envelope"></i> contact@<span class="le-color">oursupport.com</span>
    </div>
</div><!-- /.contact-row -->
<!-- ============================================================= SEARCH AREA ============================================================= -->
<div class="search-area">
    <form>
        <div class="control-group">
            <input class="search-field" placeholder="Search for item" />

            <div class="custom-select categories-filter animate-dropdown">
                <section>     
                    <select class="styled">
                        <option>All Categories</option>
                        <option>Laptops</option>
                        <option>TV & Audio</option>
                        <option>Gadgets</option>
                        <option>Cameras</option>
                    </select>
                </section>
            </div>

            <a class="search-button" href="#" ></a>    

        </div>
    </form>
</div><!-- /.search-area -->
<!-- ============================================================= SEARCH AREA : END ============================================================= -->