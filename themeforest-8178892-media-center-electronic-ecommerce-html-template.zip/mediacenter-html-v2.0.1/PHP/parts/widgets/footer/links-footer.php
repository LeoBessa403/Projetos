<!-- ============================================================= LINKS FOOTER ============================================================= -->
<div class="link-widget">
    <div class="widget">
        <h3>Find it fast</h3>
        <ul>
            <li><a href="index.php?page=category-grid">laptops &amp; computers</a></li>
            <li><a href="index.php?page=category-grid">Cameras &amp; Photography</a></li>
            <li><a href="index.php?page=category-grid">Smart Phones &amp; Tablets</a></li>
            <li><a href="index.php?page=category-grid">Video Games &amp; Consoles</a></li>
            <li><a href="index.php?page=category-grid">TV &amp; Audio</a></li>
            <li><a href="index.php?page=category-grid">Gadgets</a></li>
            <li><a href="index.php?page=category-grid">Car Electronic &amp; GPS</a></li>
            <li><a href="index.php?page=category-grid">Accesories</a></li>
        </ul>
    </div><!-- /.widget -->
</div><!-- /.link-widget -->

<div class="link-widget">
    <div class="widget">
        <h3>Information</h3>
        <ul>
            <li><a href="index.php?page=category-grid">Find a Store</a></li>
            <li><a href="index.php?page=category-grid">About Us</a></li>
            <li><a href="index.php?page=category-grid">Contact Us</a></li>
            <li><a href="index.php?page=category-grid">Weekly Deals</a></li>
            <li><a href="index.php?page=category-grid">Gift Cards</a></li>
            <li><a href="index.php?page=category-grid">Recycling Program</a></li>
            <li><a href="index.php?page=category-grid">Community</a></li>
            <li><a href="index.php?page=category-grid">Careers</a></li>

        </ul>
    </div><!-- /.widget -->
</div><!-- /.link-widget -->

<div class="link-widget">
    <div class="widget">
        <h3>Information</h3>
        <ul>
            <li><a href="index.php?page=category-grid">My Account</a></li>
            <li><a href="index.php?page=category-grid">Order Tracking</a></li>
            <li><a href="index.php?page=category-grid">Wish List</a></li>
            <li><a href="index.php?page=category-grid">Customer Service</a></li>
            <li><a href="index.php?page=category-grid">Returns / Exchange</a></li>
            <li><a href="index.php?page=category-grid">FAQs</a></li>
            <li><a href="index.php?page=category-grid">Product Support</a></li>
            <li><a href="index.php?page=category-grid">Extended Service Plans</a></li>
        </ul>
    </div><!-- /.widget -->
</div><!-- /.link-widget -->
<!-- ============================================================= LINKS FOOTER : END ============================================================= -->