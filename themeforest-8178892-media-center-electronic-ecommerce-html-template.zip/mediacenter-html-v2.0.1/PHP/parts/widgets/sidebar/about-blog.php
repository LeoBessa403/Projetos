<div class="widget">
	<h4>About Blog</h4>
	<div class="body">
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tincidunt, erat in malesuada aliquam, est erat faucibus purus, eget viverra nulla sem vitae neque. Quisque id sodales libero. </p>
	</div>
</div><!-- /.widget -->