<!-- ========================================= LINKS ========================================= -->
<div class="widget">
    <h1 class="border">information</h1>
    <div class="body">
        <ul class="le-links">
            <li><a href="#">delivery</a></li>
            <li><a href="#">secure payment</a></li>
            <li><a href="#">our stores</a></li>
            <li><a href="#">contact</a></li>
        </ul><!-- /.le-links -->
    </div><!-- /.body -->
</div><!-- /.widget -->
<!-- ========================================= LINKS : END ========================================= -->