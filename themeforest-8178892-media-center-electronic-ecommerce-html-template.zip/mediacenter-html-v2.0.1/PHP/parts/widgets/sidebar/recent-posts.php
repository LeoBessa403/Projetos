<!-- ========================================= RECENT POST ========================================= -->
<div class="widget">
    <h4>Recent Posts</h4>
    <div class="body">
        <ul class="recent-post-list">
            <li class="sidebar-recent-post-item">
                <div class="media">
                    <a href="#" class="thumb-holder pull-left">
                        <img alt="" src="assets/images/blank.gif" data-echo="assets/images/recent-posts/1.jpg" />
                    </a>
                    <div class="media-body">
                        <h5><a href="#">Coffee Time in Office </a></h5>
                        <div class="posted-date">July 12 2014</div>
                    </div>
                </div>
            </li><!-- /.sidebar-recent-post-item -->

            <li class="sidebar-recent-post-item">
                <div class="media">
                    <a href="#" class="thumb-holder pull-left">
                        <img alt="" src="assets/images/blank.gif" data-echo="assets/images/recent-posts/2.jpg" />
                    </a>
                    <div class="media-body">
                        <h5><a href="#">Lets Meet The Whole Team of MediaCenter </a></h5>
                        <div class="posted-date">July 10 2014</div>
                    </div>
                </div>
            </li><!-- /.sidebar-recent-post-item -->

            <li class="sidebar-recent-post-item">
                <div class="media">
                    <a href="#" class="thumb-holder pull-left">
                        <img alt="" src="assets/images/blank.gif" data-echo="assets/images/recent-posts/3.jpg" />
                    </a>
                    <div class="media-body">
                        <h5><a href="#">The Best Wordpress Support 24/7 </a></h5>
                        <div class="posted-date">July 06 2014</div>
                    </div>
                </div>
            </li><!-- /.sidebar-recent-post-item -->

            <li class="sidebar-recent-post-item">
                <div class="media">
                    <a href="#" class="thumb-holder pull-left">
                        <img alt="" src="assets/images/blank.gif" data-echo="assets/images/recent-posts/4.jpg" />
                    </a>
                    <div class="media-body">
                        <h5><a href="#">Gallery Post with Supported Animation</a></h5>
                        <div class="posted-date">July 04 2014</div>
                    </div>
                </div>
            </li><!-- /.sidebar-recent-post-item -->

            <li class="sidebar-recent-post-item">
                <div class="media">
                    <a href="#" class="thumb-holder pull-left">
                        <img alt="" src="assets/images/blank.gif" data-echo="assets/images/recent-posts/5.jpg" />
                    </a>
                    <div class="media-body">
                        <h5><a href="#">Sweet memories in our Store </a></h5>
                        <div class="posted-date">July 01 2014</div>
                    </div>
                </div>
            </li><!-- /.sidebar-recent-post-item -->

        </ul><!-- /.recent-post-list -->
    </div><!-- /.body -->
</div><!-- /.widget -->
<!-- ========================================= RECENT POST : END ========================================= -->