<div class="widget">
	<h4>Popular Tags</h4>
	<div class="body">
		<div class="tagcloud">
			<a style="font-size: 12pt;" href="#">Beautiful</a> 
			<a style="font-size: 20pt;" href="#">Media Center</a> 
			<a style="font-size: 10pt;" href="#">Quality</a> 
			<a style="font-size: 14pt;" href="#">Website</a> 
			<a style="font-size: 16pt;" href="#">Template</a> 
			<a style="font-size: 12pt;" href="#">Professional</a> 
			<a style="font-size: 20pt;" href="#">Design</a> 
			<a style="font-size: 10pt;" href="#">Multipurpose</a> 
			<a style="font-size: 16pt;" href="#">Portfolio</a> 
			<a style="font-size: 10pt;" href="#">Customization</a> 
			<a style="font-size: 19pt;" href="#">Bootstrap</a> 
			<a style="font-size: 9pt;" href="#">Mobile</a> 
			<a style="font-size: 14pt;" href="#">Features</a> 
			<a style="font-size: 9pt;" href="#">Styles</a> 
			<a style="font-size: 13pt;" href="#">Responsive</a> 
			<a style="font-size: 9pt;" href="#">Font Icons</a> 
			<a style="font-size: 22pt;" href="#">Love</a> 
			<a style="font-size: 10pt;" href="#">Digital</a> 
			<a style="font-size: 18pt;" href="#">Awesome</a> 
			<a style="font-size: 12pt;" href="#">Passion</a> 
			<a style="font-size: 13pt;" href="#">Typography</a> 
			<a style="font-size: 13pt;" href="#">Clean</a> 
			<a style="font-size: 9pt;" href="#">Easy to use</a> 
			<a style="font-size: 20pt;" href="#">Buy it</a> 
			<a style="font-size: 12pt;" href="#">Success</a>
		</div><!-- /.tagcloud -->
	</div><!-- /.body -->
</div><!-- /.widget -->