<div class="widget">
	<h4>Categories</h4>
	<div class="body">
		<ul class="le-links">
            <li><a href="#">Business</a></li>
            <li><a href="#">Company</a></li>
            <li><a href="#">Entertainment</a></li>
            <li><a href="#">Health</a></li>
            <li><a href="#">News</a></li>
            <li><a href="#">Stories</a></li>
            <li><a href="#">Travel</a></li>
        </ul><!-- /.le-links -->
	</div>
</div><!-- /.widget -->