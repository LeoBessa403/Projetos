<div class="yamm-content">
    <div class="row">
       <div class="col-xs-12 col-sm-4">
            <h2>Laptops &amp; Notebooks</h2>
            <ul>
                <li><a href="#">Power Supplies Power</a></li>
                <li><a href="#">Power Supply Testers Sound </a></li>
                <li><a href="#">Sound Cards (Internal)</a></li>
                <li><a href="#">Video Capture &amp; TV Tuner Cards</a></li>
                <li><a href="#">Other</a></li>
            </ul>
        </div><!-- /.col -->

        <div class="col-xs-12 col-sm-4">
            <h2>Computers &amp; Laptops</h2>
            <ul>
                <li><a href="#">Computer Cases &amp; Accessories</a></li>
                <li><a href="#">CPUs, Processors</a></li>
                <li><a href="#">Fans, Heatsinks &amp; Cooling</a></li>
                <li><a href="#">Graphics, Video Cards</a></li>
                <li><a href="#">Interface, Add-On Cards</a></li>
                <li><a href="#">Laptop Replacement Parts</a></li>
                <li><a href="#">Memory (RAM)</a></li>
                <li><a href="#">Motherboards</a></li>
                <li><a href="#">Motherboard &amp; CPU Combos</a></li>
                <li><a href="#">Motherboard Components &amp; Accs</a></li>
            </ul>
        </div><!-- /.col -->

        <div class="col-xs-12 col-sm-4">
            <h2>Dekstop Parts</h2>
            <ul>
                <li><a href="#">Power Supplies Power</a></li>
                <li><a href="#">Power Supply Testers Sound</a></li>
                <li><a href="#">Sound Cards (Internal)</a></li>
                <li><a href="#">Video Capture &amp; TV Tuner Cards</a></li>
                <li><a href="#">Other</a></li>
            </ul>
        </div><!-- /.col -->
    </div><!-- /.row -->
</div><!-- /.yamm-content -->