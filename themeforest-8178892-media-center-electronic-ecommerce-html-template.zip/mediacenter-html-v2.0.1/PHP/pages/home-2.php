<div id="top-banner-and-menu" class="homepage2">
	<div class="container">
		<div class="col-xs-12">
			<?php require MC_ROOT.'/parts/section/home-page-slider-2.php';?>
		</div>
	</div>
</div><!-- /.homepage2 -->

<?php require MC_ROOT.'/parts/section/home-banners.php';?>

<?php require MC_ROOT.'/parts/section/home-page-tabs.php';?>

<?php require MC_ROOT.'/parts/section/best-sellers.php';?>

<?php require MC_ROOT.'/parts/section/recently-viewed.php';?>

<?php require MC_ROOT.'/parts/section/top-brands.php';?>