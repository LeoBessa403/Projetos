<div id="top-banner-and-menu">
	<div class="container">
		
		<div class="col-xs-12 col-sm-4 col-md-3 sidemenu-holder">
			<?php require MC_ROOT.'/parts/navigation/sidemenu.php' ?>
		</div><!-- /.sidemenu-holder -->

		<div class="col-xs-12 col-sm-8 col-md-9 homebanner-holder">
			<?php require MC_ROOT.'/parts/section/home-page-slider.php' ?>			
		</div><!-- /.homebanner-holder -->

	</div><!-- /.container -->
</div><!-- /#top-banner-and-menu -->

<?php require MC_ROOT.'/parts/section/home-banners.php';?>

<?php require MC_ROOT.'/parts/section/home-page-tabs.php';?>

<?php require MC_ROOT.'/parts/section/best-sellers.php';?>

<?php require MC_ROOT.'/parts/section/recently-viewed.php';?>

<?php require MC_ROOT.'/parts/section/top-brands.php';?>