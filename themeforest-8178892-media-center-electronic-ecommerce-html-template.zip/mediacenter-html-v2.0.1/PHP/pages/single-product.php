<div id="single-product">
    <div class="container">

        <?php require MC_ROOT.'/parts/section/single-product-gallery.php';?>
        
        <?php require MC_ROOT.'/parts/section/single-product-detail.php';?>

    </div><!-- /.container -->
</div><!-- /.single-product -->

<?php require MC_ROOT.'/parts/section/single-product-tab.php';?>

<?php require MC_ROOT.'/parts/section/recently-viewed.php';?>