<!-- ========================================= MAIN ========================================= -->
<main id="blog" class="inner-bottom-xs">
	<div class="container">
		
		<div class="row">
			<div class="col-md-9">
				
				<?php require MC_ROOT.'/parts/section/blog-posts.php';?>

			</div><!-- /.col -->

			<div class="col-md-3">
				
				<?php require MC_ROOT. '/parts/section/blog-sidebar.php'; ?>

			</div>
		</div><!-- /.row -->

	</div><!-- /.container -->
</main><!-- /.inner-bottom-xs -->
<!-- ========================================= MAIN : MAIN ========================================= -->