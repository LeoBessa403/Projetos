<!-- ========================================= MAIN ========================================= -->
<main id="blog" class="inner-bottom-xs">
	<div class="container">
		
		<div class="row">
			<div class="col-md-12">
				
				<?php require MC_ROOT.'/parts/section/blog-posts.php';?>

			</div><!-- /.col -->
		</div><!-- /.row -->

	</div><!-- /.container -->
</main><!-- /.inner-bottom-xs -->
<!-- ========================================= MAIN : MAIN ========================================= -->